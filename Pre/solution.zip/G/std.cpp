#include<bits/stdc++.h>
using namespace std;

string mp[1000], mpp[1000];

int n, m, o = 0, x = 0;

void printans() {
    for(int i = 0; i < n; i++) {
        cout << mpp[i] << '\n';
    }
}

int main() {
    cin >> n >> m;
    for(int i = 0; i < n; i++) {
        cin >> mp[i];
        for(int j = 0; j < m; j++) {
            if(mp[i][j] == 'O') {
                o++;
            }
        }
    }
    for(int i = 0; i < 5; i++) {
        x = 0;
        for(int j = 0; j < n; j++) {
            mpp[j] = mp[j];
        }
        for(int j = 0; j < n; j++) {
            for(int k = (i + j * 2) % 5; k < m; k += 5) {
                if(mpp[j][k] == 'O') {
                    mpp[j][k] = 'X', x++;
                }
            }
        }
        if(x <= o / 5) {
            printans();
            break;
        }
    }
    return 0;
}