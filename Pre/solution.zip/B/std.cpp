#include<bits/stdc++.h>
using namespace std;

int main()
{
	int n,tmp;
	scanf("%d",&n);
	for (int i=1;i<=5;i++)
	{
		scanf("%d",&tmp);
		if (n>=10000) n=max(10000,n+tmp);
		else if (n>=7200) n=max(7200,n+tmp);
		else if (n>=4800) n=max(4800,n+tmp);
		else if (n>=2400) n=max(2400,n+tmp);
		else if (n>=1200) n=max(1200,n+tmp);
		else n=max(0,n+tmp);
	}
	printf("%d\n",n);
	return 0;
}
