#include<bits/stdc++.h>
using namespace std;

int a[] = {0, 1200, 2400, 4800, 7200, 10000};
int main() {
    int s; 
    cin >> s;
    for(int i = 1, x; i <= 5; i++) {
        cin >> x;
        s = max(s + x, *(upper_bound(a, a + 6, s) - 1));
    }
    cout << s;
    
    return 0;
}