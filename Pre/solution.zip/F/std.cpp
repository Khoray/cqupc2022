#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int maxn=2e5+5;
int a[maxn],b[maxn];
ll sum[maxn],mer[maxn];
ll ans;
void mergesort(int l,int r) {
    if(l==r) return;
    int mid=l+r>>1;
    mergesort(l,mid);
    mergesort(mid+1,r);
    int pr1=l,pr2=mid+1,pr=l;
    while(pr1<=mid&&pr2<=r){
        if(sum[pr1]<=sum[pr2]){
            mer[pr++]=sum[pr1++];
        } else {
            mer[pr++]=sum[pr2++];
            ans+=mid-pr1+1;
        }
    }
    while(pr1<=mid){
        mer[pr++]=sum[pr1++];
    }
    while(pr2<=r){
        mer[pr++]=sum[pr2++];
    }
    for(int i=l;i<=r;i++) sum[i]=mer[i];
}
int main() {
	cin.tie(0)->sync_with_stdio(false);
    int n,x;cin>>n>>x;
    for(int i=1;i<=n;i++){
        cin>>a[i];
    }
    for(int i=1;i<=n;i++){
        cin>>b[i];
        int tmp=(a[i]-x)*b[i];
        sum[i]=sum[i-1]+tmp;
    }
    mergesort(0,n);
    cout<<ans;

    return 0;
}