#include<bits/stdc++.h>
using namespace std;

int main() {
    for(int i = 1; i <= 12; i++) {
        system((string("std.exe < datas/") + to_string(i) + ".in > datas/" + to_string(i) + ".out").c_str());
    }
    return 0;
}