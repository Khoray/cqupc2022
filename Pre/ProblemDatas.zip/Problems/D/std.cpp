#include<bits/stdc++.h>
using namespace std;

char c[10];
char d[10];

int main()
{
	int n,k,x,y,f=0,sum=0;
	scanf("%d%d",&n,&k);
	for (int i=1;i<=n;i++)
	{
		scanf("%d%d",&x,&y);
		if (x==1+2*k&&y==1||x==1+k&&y==1+k||x==1&&y==1+2*k)
		{
			f=1;
			break;
		}
		if (x%k==1&&y%k==1&&(x+y-2)/k%2==0) f=2,sum+=(x+y-2)/k/2;
		else sum+=((x-1)/k+(y-1)/k)/2-2;
	}
	if (f==2)
	{
		if (sum%2) f=1;
		else f=-1;
	}
	if (f==1) printf("Yes\n");
	else if (f==-1) printf("No\n");
	else printf("Tie\n");
	return 0;
}
