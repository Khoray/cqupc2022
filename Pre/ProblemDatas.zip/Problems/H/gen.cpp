#include<bits/stdc++.h>
using namespace std;
#define int long long

mt19937 rnd(time(0));

#define randint(l, r) uniform_int_distribution<int> (l, r) (rnd)

void genone(int test, int tot) {
    freopen((string("datas/") + to_string(test) + ".in").c_str(), "w", stdout);
    int m = randint(-1e9, 1e9);
    vector<int> cs;
    while(tot > 1000) {
        int nowc = 1000;
        cs.push_back(nowc);
        tot -= nowc;
    }
    cs.push_back(tot);
    int n = cs.size();
    cout << n << ' ' << m << '\n';
    for(int i = 0; i < n; i++) {
        cout << cs[i] << ' ';
        for(int j = 0; j <= cs[i]; j++) {
            cout << randint(-1e9, 1e9) << ' ';
        }
        cout << '\n';
    }
}

void genone2(int test, int tot) {
    freopen((string("datas/") + to_string(test) + ".in").c_str(), "w", stdout);
    int m = randint(-1e9, 1e9);
    vector<int> cs;
    while(tot > 1) {
        int nowc = 1;
        cs.push_back(nowc);
        tot -= nowc;
    }
    cs.push_back(tot);
    int n = cs.size();
    cout << n << ' ' << m << '\n';
    for(int i = 0; i < n; i++) {
        cout << cs[i] << ' ';
        for(int j = 0; j <= cs[i]; j++) {
            cout << randint(-1e9, 1e9) << ' ';
        }
        cout << '\n';
    }
}

signed main() {
    // for(int i = 2; i <= 5; i++) {
    //     genone(i, 20);
    // }
    // for(int i = 6; i <= 10; i++) {
    //     genone(i, 1e5);
    // }
    // genone2(11, 1e5);
    // genone2(12, 1e5);
    // for(int i = 13; i <= 15; i++) {
    //     genone(i, 1e5);
    // }
    // for(int i = 16; i <= 18; i++) {
    //     genone(i, 1e5);
    // }
    for(int i = 19; i <= 20; i++) {
        genone(i, 1e5);
    }
    return 0;
}
