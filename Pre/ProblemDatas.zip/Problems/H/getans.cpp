#include<bits/stdc++.h>
using namespace std;

int main() {
    for(int i = 13; i <= 20; i++) {
        system((string("std.exe < datas/") + to_string(i) + ".in > datas/" + to_string(i) + ".out").c_str());
    }
    return 0;
}