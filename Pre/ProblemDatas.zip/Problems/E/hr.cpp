#include<bits/stdc++.h>
using namespace std;

const int inf = 0x3f3f3f3f;

int main() {
    int n; cin >> n;
    vector<pair<int, int>> a(n + 2);
    cin >> a[0].first >> a[0].second;
    vector<vector<int>> x(1e5 + 1), y(1e5 + 1), dis(n + 2, vector<int> (2, inf));
    cin >> a[n + 1].first >> a[n + 1].second;
    y[a[n + 1].first].push_back(a[n + 1].second);
    x[a[n + 1].second].push_back(a[n + 1].first);
    map<pair<int, int>, int> id;
    int tot = 0;
    id[{a[0].first, a[0].second}] = 0;
    id[{a[n + 1].first, a[n + 1].second}] = n + 1;
    for(int i = 1; i <= n; i++) {
        cin >> a[i].first >> a[i].second;
        y[a[i].first].push_back(a[i].second);
        x[a[i].second].push_back(a[i].first);
        id[{a[i].first, a[i].second}] = i;
    }
    for(int i = 1; i <= 1e5; i++) {
        sort(x[i].begin(), x[i].end());
        sort(y[i].begin(), y[i].end());
    }
    queue<pair<int, int>> q;
    dis[0][0] = 0;
    dis[0][1] = 0;
    q.push({0, 0});
    q.push({0, 1});
    function<int(int, int)> getnx = [&] (int u, int dir) -> int {
        int ux = a[u].first;
        int uy = a[u].second;
        if(dir == 0) { // up
            vector<int>::iterator it = upper_bound(y[ux].begin(), y[ux].end(), uy);
            if(it != y[ux].end()) return id[{ux, *it}];
        }
        if(dir == 1) { // down
            vector<int>::iterator it = lower_bound(y[ux].begin(), y[ux].end(), uy);
            if(it != y[ux].begin()) return id[{ux, *(it - 1)}];
        }
        if(dir == 2) { // left
            vector<int>::iterator it = lower_bound(x[uy].begin(), x[uy].end(), ux);
            if(it != x[uy].begin()) return id[{*(it - 1), uy}];
        }
        if(dir == 3) { // right
            vector<int>::iterator it = upper_bound(x[uy].begin(), x[uy].end(), ux);
            if(it != x[uy].end()) return id[{*it, uy}];
        }
        return -1;
    };
    while(q.size()) {
        int u = q.front().first;
        int dir = q.front().second;
        q.pop();
        if(dir == 0) { // up and down
            int v1 = getnx(u, 0);
            int v2 = getnx(u, 1);
            if(v1 != -1 && dis[v1][1] == inf) {
                dis[v1][1] = dis[u][0] + 1;
                q.emplace(v1, 1);
            }
            if(v2 != -1 && dis[v2][1] == inf) {
                dis[v2][1] = dis[u][0] + 1;
                q.emplace(v2, 1);
            }
        } else {
            int v1 = getnx(u, 2);
            int v2 = getnx(u, 3);
            if(v1 != -1 && dis[v1][0] == inf) {
                dis[v1][0] = dis[u][1] + 1;
                q.emplace(v1, 0);
            }
            if(v2 != -1 && dis[v2][0] == inf) {
                dis[v2][0] = dis[u][1] + 1;
                q.emplace(v2, 0);
            }
        }
    }

    int ans = min(dis[n + 1][0], dis[n + 1][1]);
    if(ans == inf) {
        cout << -1;
    } else {
        cout << ans - 1;
    }
    return 0;
}