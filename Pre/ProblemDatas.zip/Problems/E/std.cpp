#include<bits/stdc++.h>
using namespace std;
const int N=1e5+5;
int n,x[N],y[N],xcnt,ycnt,d[4][N];
struct node{int x,y;}p[N];
set<int>hx[N],hy[N];
bool vis[4][N];
struct Que{int x,dct;};
map<int,int>to[N];
int out[4][2]={{1,3},{0,2},{1,3},{0,2},};
void bfs(){
    queue<Que>q;
    Que x;
    memset(d,0x3f,sizeof(d));
    set<int>::iterator it;
    for(int i=0;i<4;i++){
        vis[i][1]=1;d[i][1]=0;
        q.push({1,i});
    }
    while(!q.empty()){
        x=q.front();
        q.pop();int y;
        // cout<<"Q "<<x.x<<' '<<x.dct<<'\n';
        switch(x.dct){
            case 0:{
                it=hy[p[x.x].y].lower_bound(p[x.x].x);
                if(it==hy[p[x.x].y].begin())continue;
                it--;
                y=to[*it][p[x.x].y];
            }
            break;
            case 1:{
                it=hx[p[x.x].x].lower_bound(p[x.x].y);
                // cout<<p[x.x].x<<' '<<p[x.x].y<<' '<<hx[p[x.x].x].count(p[x.x].y)<<' '<<*it<<'\n';
                it++;
                if(it==hx[p[x.x].x].end())continue;
                y=to[p[x.x].x][*it];
            }
            break;
            case 2:{
                it=hy[p[x.x].y].lower_bound(p[x.x].x);
                it++;
                if(it==hy[p[x.x].y].end())continue;
                y=to[*it][p[x.x].y];
            }
            break;
            case 3:{
                it=hx[p[x.x].x].lower_bound(p[x.x].y);
                // cout<<p[x.x].x<<' '<<p[x.x].y<<' '<<hx[p[x.x].x].count(p[x.x].y)<<' '<<*it<<'\n';
                if(it==hx[p[x.x].x].begin())continue;
                it--;
                y=to[p[x.x].x][*it];
            }
            break;
        }
        // cout<<y<<'\n';
        for(int i=0;i<2;i++){
            if(vis[out[x.dct][i]][y])continue;
            vis[out[x.dct][i]][y]=1;
            d[out[x.dct][i]][y]=d[x.dct][x.x]+1;
            q.push({y,out[x.dct][i]});
        }

    }
    int ans=1e8;
    for(int i=0;i<4;i++)ans=min(ans,d[i][n]);
    cout<<(ans==1e8?-1:ans-1);
}
int main()
{
    int i,j;
    cin.tie(0);
    ios::sync_with_stdio(false);
    cin>>n;n+=2;
    cin>>p[1].x>>p[1].y,x[1]=p[1].x,y[1]=p[1].y;
    cin>>p[n].x>>p[n].y,x[n]=p[n].x,y[n]=p[n].y;
    for(i=2;i<n;i++)cin>>p[i].x>>p[i].y,x[i]=p[i].x,y[i]=p[i].y;
    sort(x+1,x+1+n);
    sort(y+1,y+1+n);
    xcnt=unique(x+1,x+1+n)-x-1;
    ycnt=unique(y+1,y+1+n)-y-1;
    for(i=1;i<=n;i++){
        p[i].x=lower_bound(x+1,x+1+xcnt,p[i].x)-x;
        p[i].y=lower_bound(y+1,y+1+ycnt,p[i].y)-y;
        to[p[i].x][p[i].y]=i;
        // cout<<"* "<<p[i].x<<' '<<p[i].y<<'\n';
    }
    for(i=1;i<=n;i++){
        hx[p[i].x].insert(p[i].y);
        hy[p[i].y].insert(p[i].x);
    }
    bfs();
}
/*
7
1 2
2 1
2 3
3 1
3 2
3 3
4 2
*/
