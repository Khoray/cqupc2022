#include"testlib.h"
#include<bits/stdc++.h>
using namespace std;
int m, n;
string mp[1000];
int Check() {
    //row
    for(int i = 0; i < n; i++) {
        int cnt = 0;
        for(int j = 0; j < m; j++) {
            if(mp[i][j] == 'O') {
                cnt++;
            } else {
                cnt = 0;
            }
            if(cnt >= 5) {
                quitf(_wa, "Diana can get five.");
            }
        }
    }
    //col
    for(int i = 0; i < m; i++) {
        int cnt = 0;
        for(int j = 0; j < n; j++) {
            if(mp[j][i] == 'O') {
                cnt++;
            } else {
                cnt = 0;
            }
            if(cnt >= 5) {
                quitf(_wa, "Diana can get five.");
            }
        }
    }
    //ru->ld
    for(int i = 0; i < m; i++) {
        if(i == 9) {
            int stop = 1;
        }
        int cnt = 0;
        for(int j = 0; j <= i && j < n; j++) {
            if(mp[j][i - j] == 'O') {
                cnt++;
            } else {
                cnt = 0;
            }
            if(cnt >= 5) {
                quitf(_wa, "Diana can get five.");
            }
        }
    }
    for(int i = 1; i < n; i++) {
        int cnt = 0;
        for(int j = 0; j < m && i + j < n; j++) {
            if(mp[j + i][n - j - 1] == 'O') {
                cnt++;
            } else {
                cnt = 0;
            }
            if(cnt >= 5) {
                quitf(_wa, "Diana can get five.");
            }
        }
    }
    //rd-lu
    for(int i = 0; i < m; i++) {
        int cnt = 0;
        for(int j = 0; j < n && i + j < m; j++) {
            if(mp[j][i + j] == 'O') {
                cnt++;
            } else {
                cnt = 0;
            }
            if(cnt >= 5) {
                quitf(_wa, "Diana can get five.");
            }
        }
    }
    for(int i = 1; i < n; i++) {
        int cnt = 0;
        for(int j = 0; j < m && i + j < n; j++) {
            if(mp[j + i][j] == 'O') {
                cnt++;
            } else {
                cnt = 0;
            }
            if(cnt >= 5) {
                quitf(_wa, "Diana can get five.");
            }
        }
    }
    quitf(_ok, "OK.");
}
int main(int argc, char *argv[]) {
    
    registerTestlibCmd(argc, argv);
    n = inf.readInt();
    m = inf.readInt();
    inf.readEoln();
    int o = 0, x = 0;
    for(int i = 0; i < n; i++) {
        mp[i] = ouf.readString();
        string comp = inf.readString();
        if(mp[i].length() != m) {
            quitf(_pe, "the output format is inlegal.");
        }
        for(int j = 0; j < m; j++) {
            if(mp[i][j] == 'X' && comp[j] == 'O') {
                o++, x++;
            } else if(mp[i][j] == 'O' && comp[j] == 'O') {
                o++;
            } else if(mp[i][j] != comp[j]) {
                quitf(_wa, "position (%d,%d) is inlegally different!", i + 1, j + 1);
            }
        }
    }
    if(x > o / 5) {
        quitf(_wa, "x is more than o/5.");
    }
    Check();
    return 0;
}