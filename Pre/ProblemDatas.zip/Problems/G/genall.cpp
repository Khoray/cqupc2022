#include<bits/stdc++.h>
using namespace std;

int main() {
    freopen("datas/11.in", "w", stdout);
    cout << 1000 << ' ' << 1000 << '\n';
    for(int i = 1; i <= 1000; i++) {
        for(int j = 1; j <= 1000; j++) {
            cout << 'O';
        }
        cout << '\n';
    }
    return 0;
}