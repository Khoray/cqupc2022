#include<bits/stdc++.h>
using namespace std;
int m, n;
string mp[1000];
int Check(ofstream &log) {
    //row
    for(int i = 0; i < n; i++) {
        int cnt = 0;
        for(int j = 0; j < m; j++) {
            if(mp[i][j] == 'O') {
                cnt++;
            } else {
                cnt = 0;
            }
            if(cnt >= 5) {
                log << "ytrsk can get five.";
                return 1;
            }
        }
    }
    //col
    for(int i = 0; i < m; i++) {
        int cnt = 0;
        for(int j = 0; j < n; j++) {
            if(mp[j][i] == 'O') {
                cnt++;
            } else {
                cnt = 0;
            }
            if(cnt >= 5) {
                log << "ytrsk can get five.";
                return 1;
            }
        }
    }
    //ru->ld
    for(int i = 0; i < m; i++) {
        int cnt = 0;
        for(int j = 0; j <= i && j < n; j++) {
            if(mp[j][i - j] == 'O') {
                cnt++;
            } else {
                cnt = 0;
            }
            if(cnt >= 5) {
                log << "ytrsk can get five.";
                return 1;
            }
        }
    }
    for(int i = 1; i < n; i++) {
        int cnt = 0;
        for(int j = 0; j < m && i + j < n; j++) {
            if(mp[j + i][n - j - 1] == 'O') {
                cnt++;
            } else {
                cnt = 0;
            }
            if(cnt >= 5) {
                log << "ytrsk can get five.";
                return 1;
            }
        }
    }
    //rd-lu
    for(int i = 0; i < m; i++) {
        int cnt = 0;
        for(int j = 0; j < n && i + j < m; j++) {
            if(mp[j][i + j] == 'O') {
                cnt++;
            } else {
                cnt = 0;
            }
            if(cnt >= 5) {
                log << "ytrsk can get five.";
                return 1;
            }
        }
    }
    for(int i = 1; i < n; i++) {
        int cnt = 0;
        for(int j = 0; j < m && i + j < n; j++) {
            if(mp[j + i][j] == 'O') {
                cnt++;
            } else {
                cnt = 0;
            }
            if(cnt >= 5) {
                log << "ytrsk can get five.";
                return 1;
            }
        }
    }
    return 0;
}
int main(int argc, char *argv[]) {
    ofstream log("/var/log/spj.log");
    string in_filename;
    getline(cin,in_filename);
    ifstream inf(in_filename.c_str());

    string stdout_filename;
    getline(cin,stdout_filename);
    ifstream ans(stdout_filename.c_str());

    string out_filename;
    getline(cin,out_filename);
    ifstream ouf(out_filename.c_str());

    inf >> n;
    inf >> m;
    // n = inf.readInt();
    // m = inf.readInt();
    // inf.readEoln();
    int o = 0, x = 0;
    for(int i = 0; i < n; i++) {
        ouf >> mp[i];
        string comp;
        inf >> comp;
        if((int) mp[i].length() != m) {
            log << "the output format is inlegal.";
            return 1;
        }
        for(int j = 0; j < m; j++) {
            if(mp[i][j] == 'X' && comp[j] == 'O') {
                o++, x++;
            } else if(mp[i][j] == 'O' && comp[j] == 'O') {
                o++;
            } else if(mp[i][j] != comp[j]) {
                log << "position (" << i + 1 << ", " << j + 1 << ") is inlegally different!";
                return 1;
            }
        }
    }
    if(x > o / 5) {
        log << "x is more than o/5.";
        return 1;
    }
    return Check(log);
}