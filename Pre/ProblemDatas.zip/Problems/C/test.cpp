#include<bits/stdc++.h>
using namespace std;

int main()
{
	long long n;
	cin>>n;
	long long ans=1;
	for (int i=2;1ll*i*i<=n;i++)
	{
		if (n%i==0)
		{
			int sum=1;
			while (n%i==0) n=n/i,sum++;
			ans=ans*sum;
		}
		if (n==1) break;
	}
	if (n>1) ans=ans*2;
	cout<<ans<<endl;
	return 0;
}
