#include<bits/stdc++.h>
using namespace std;

char c[10];

int main()
{
	srand(time(0));
	for (int i=0;i<10;i++)
	{
		c[0]=i+'0';
		c[1]='.';
		c[2]='i';
		c[3]='n';
		c[4]='\0';
		freopen(c,"w",stdout);
		printf("%lld\n",1ll*rand()*rand()*rand()*rand()%1000000000000ll);
	}
	return 0;
}
