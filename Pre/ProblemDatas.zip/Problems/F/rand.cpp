#include<bits/stdc++.h>
using namespace std;
#define int long long
mt19937 mt(time(0));
signed main() {
    int n = 3, k = 3;
    cout << n << '\n' << k << '\n';
    for(int i = 1; i <= n; i++) {
        cout << uniform_int_distribution<int>(1, 5)(mt) << ' ';
    }
    cout << '\n';
    for(int i = 1; i <= n; i++) {
        cout << 1 << ' ';
    }

    return 0;
}