#include<bits/stdc++.h>
using namespace std;
#define int long long

mt19937 rnd(time(0));

#define randint(l, r) uniform_int_distribution<int> (l, r) (rnd)

void genone(int test, int tot) {
    freopen((string("datas/") + to_string(test) + ".in").c_str(), "w", stdout);
    cout << tot << ' ' << randint(1, 1e5) << '\n';
    for(int i = 1; i <= tot; i++) {
        cout << randint(1, 1e5) << ' ';
    }
    cout << '\n';
    for(int i = 1; i <= tot; i++) {
        cout << randint(1, 1e4) << ' ';
    }
}

signed main() {
    for(int i = 3; i <= 10; i++) {
        genone(i, 2e5);
    }
    return 0;
}
