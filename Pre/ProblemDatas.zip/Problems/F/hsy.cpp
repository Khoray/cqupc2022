#include<bits/stdc++.h>
#define int long long
using namespace std;
const int N=2e5+5;
int n,k,a[N],s[N],ans;
void erfen(int l,int r){
	if(l==r)return;
	int mid=l+r>>1;
	erfen(l,mid),erfen(mid+1,r);
	int i;
	
	vector<int>left,right;
	for(i=l;i<=mid;i++)left.push_back(s[i]);
	for(i=mid+1;i<=r;i++)right.push_back(s[i]);
	sort(left.begin(),left.end());
	sort(right.begin(),right.end());
	int p=l,tot=(mid-l+1)*(r-mid),tmp=0;
	for(auto x:right){
		while(p<=mid&&x-s[p]>=0)p++;
		tmp+=p-l;
	}
	// cout<<l<<' '<<mid<<' '<<r<<' '<<tot<<' '<<tmp<<'\n';
	ans+=tot-tmp;
}
signed main()
{
	int i,x;
	cin>>n>>k;
	for(i=1;i<=n;i++)cin>>a[i];
	for(i=1;i<=n;i++){
		cin>>x;
		s[i]=s[i-1]+(a[i]-k)*x;
		if((a[i]-k)*x<0)ans++;
	}
	erfen(1,n);
	cout<<ans;
}

/*
5 5
5 5 4 5 5
1 1 1 1 1

*/