#include<bits/stdc++.h>
using namespace std;
#define int long long

struct Fenwick {
    vector<int> fen;
    Fenwick(int n) : fen(n + 1) { }
    void add(int pos, int val) {
        for(; pos < fen.size(); pos += pos & -pos) {
            fen[pos] += val;
        }
    }
    int query(int pos) {
        int ret = 0;
        for(; pos > 0; pos -= pos & -pos) {
            ret += fen[pos];
        }
        return ret;
    }
    int query(int l, int r) {
        return query(r) - query(l - 1);
    }
};

signed main() {
    int n, x;
    cin >> n >> x;
    vector<int> a(n + 1), b(n + 1), sum(n + 1);
    for(int i = 1; i <= n; i++) {
        cin >> a[i];
    }
    for(int i = 1; i <= n; i++) {
        cin >> b[i];
        int tmp = (a[i] - x) * b[i];
        sum[i] = sum[i - 1] + tmp;
    }
    vector<int> un = sum;
    sort(un.begin(), un.end());
    un.erase(unique(un.begin(), un.end()), un.end());
    auto getid = [&] (int x) {
        return lower_bound(un.begin(), un.end(), x) - un.begin() + 1;
    };
    Fenwick fwk(n + 2);
    int ans = 0;
    for(int i = 0; i <= n; i++) {
        sum[i] = getid(sum[i]);
        ans += fwk.query(sum[i] + 1, n + 2);
        fwk.add(sum[i], 1);
    }
    cout << ans;

    return 0;
}