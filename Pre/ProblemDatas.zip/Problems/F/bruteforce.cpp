#include<bits/stdc++.h>
using namespace std;
#define ll long long
const int maxn = 2e5 + 5;
int a[maxn], b[maxn];
ll ans;

int main() {
    int n, x;
    cin >> n >> x;
    for(int i = 1; i <= n; i++) {
        cin >> a[i];
    }
    for(int i = 1; i <= n; i++) {
        cin >> b[i];
    }
    for(int i = 1; i <= n; i++) {
        ll sum = 0, bsum = 0;
        for(int j = i; j <= n; j++) {
            sum += a[j] * b[j];
            bsum += b[j];
            if(sum < x * bsum) {
                ans++;
            }
        }
    }
    cout << ans;

    return 0;
}