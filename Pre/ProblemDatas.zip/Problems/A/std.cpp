#include<bits/stdc++.h>
using namespace std;

int main() {
    // cout << "tions to ytrsk";
    return 0;
}